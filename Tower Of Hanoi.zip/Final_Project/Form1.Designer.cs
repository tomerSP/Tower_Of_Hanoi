﻿
namespace Final_Project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboPieceNumber = new System.Windows.Forms.ComboBox();
            this.Ellipse_radioButton = new System.Windows.Forms.RadioButton();
            this.Hexagon_radioButton = new System.Windows.Forms.RadioButton();
            this.Trapez_radioButton = new System.Windows.Forms.RadioButton();
            this.btn_Save = new System.Windows.Forms.Button();
            this.btn_Load = new System.Windows.Forms.Button();
            this.lbl_MoveCounter = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // comboPieceNumber
            // 
            this.comboPieceNumber.FormattingEnabled = true;
            this.comboPieceNumber.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6"});
            this.comboPieceNumber.Location = new System.Drawing.Point(500, 12);
            this.comboPieceNumber.Name = "comboPieceNumber";
            this.comboPieceNumber.Size = new System.Drawing.Size(109, 21);
            this.comboPieceNumber.TabIndex = 0;
            this.comboPieceNumber.Text = "Number Of Pieces";
            this.comboPieceNumber.SelectedIndexChanged += new System.EventHandler(this.comboPieceNumer_Changed);
            // 
            // Ellipse_radioButton
            // 
            this.Ellipse_radioButton.AutoSize = true;
            this.Ellipse_radioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Ellipse_radioButton.Location = new System.Drawing.Point(400, 12);
            this.Ellipse_radioButton.Name = "Ellipse_radioButton";
            this.Ellipse_radioButton.Size = new System.Drawing.Size(67, 21);
            this.Ellipse_radioButton.TabIndex = 1;
            this.Ellipse_radioButton.TabStop = true;
            this.Ellipse_radioButton.Text = "Ellipse";
            this.Ellipse_radioButton.UseVisualStyleBackColor = true;
            this.Ellipse_radioButton.Click += new System.EventHandler(this.SelectedEllipse);
            // 
            // Hexagon_radioButton
            // 
            this.Hexagon_radioButton.AutoSize = true;
            this.Hexagon_radioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Hexagon_radioButton.Location = new System.Drawing.Point(400, 37);
            this.Hexagon_radioButton.Name = "Hexagon_radioButton";
            this.Hexagon_radioButton.Size = new System.Drawing.Size(82, 21);
            this.Hexagon_radioButton.TabIndex = 2;
            this.Hexagon_radioButton.TabStop = true;
            this.Hexagon_radioButton.Text = "Hexagon";
            this.Hexagon_radioButton.UseVisualStyleBackColor = true;
            this.Hexagon_radioButton.Click += new System.EventHandler(this.SelectedHexagon);
            // 
            // Trapez_radioButton
            // 
            this.Trapez_radioButton.AutoSize = true;
            this.Trapez_radioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Trapez_radioButton.Location = new System.Drawing.Point(400, 62);
            this.Trapez_radioButton.Name = "Trapez_radioButton";
            this.Trapez_radioButton.Size = new System.Drawing.Size(71, 21);
            this.Trapez_radioButton.TabIndex = 3;
            this.Trapez_radioButton.TabStop = true;
            this.Trapez_radioButton.Text = "Trapez";
            this.Trapez_radioButton.UseVisualStyleBackColor = true;
            this.Trapez_radioButton.Click += new System.EventHandler(this.SelectedTrapez);
            // 
            // btn_Save
            // 
            this.btn_Save.Location = new System.Drawing.Point(653, 12);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(89, 34);
            this.btn_Save.TabIndex = 4;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = true;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // btn_Load
            // 
            this.btn_Load.Location = new System.Drawing.Point(761, 12);
            this.btn_Load.Name = "btn_Load";
            this.btn_Load.Size = new System.Drawing.Size(89, 34);
            this.btn_Load.TabIndex = 5;
            this.btn_Load.Text = "Load";
            this.btn_Load.UseVisualStyleBackColor = true;
            this.btn_Load.Click += new System.EventHandler(this.btn_Load_Click);
            // 
            // lbl_MoveCounter
            // 
            this.lbl_MoveCounter.AutoSize = true;
            this.lbl_MoveCounter.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.lbl_MoveCounter.Location = new System.Drawing.Point(498, 64);
            this.lbl_MoveCounter.Name = "lbl_MoveCounter";
            this.lbl_MoveCounter.Size = new System.Drawing.Size(120, 19);
            this.lbl_MoveCounter.TabIndex = 6;
            this.lbl_MoveCounter.Text = "Move Count: 0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(934, 461);
            this.Controls.Add(this.lbl_MoveCounter);
            this.Controls.Add(this.btn_Load);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.Trapez_radioButton);
            this.Controls.Add(this.Hexagon_radioButton);
            this.Controls.Add(this.comboPieceNumber);
            this.Controls.Add(this.Ellipse_radioButton);
            this.Name = "Form1";
            this.Text = "Tower Of Hanoi: Tomer And Yinon";
            this.Load += new System.EventHandler(this.Form1_OnLoad);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_OnMouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_OnMouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Form1_OnMouseUp);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboPieceNumber;
        private System.Windows.Forms.RadioButton Ellipse_radioButton;
        private System.Windows.Forms.RadioButton Hexagon_radioButton;
        private System.Windows.Forms.RadioButton Trapez_radioButton;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Button btn_Load;
        private System.Windows.Forms.Label lbl_MoveCounter;
    }
}

