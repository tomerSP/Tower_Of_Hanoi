﻿using Figures;
using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;


namespace Final_Project
{
    
    public partial class Form1 : Form
    {
        TowerOfHanoi towerA = new TowerOfHanoi(WhichTower.first);
        TowerOfHanoi towerB = new TowerOfHanoi(WhichTower.second);
        TowerOfHanoi towerC = new TowerOfHanoi(WhichTower.third);

        //Piece Movement items
        bool Mouse_Holding_Shape = false;
        Shape shapeDrag = null;
        WhichTower originalTower = WhichTower.first;

        //Game Stats
        int moveCount = 0;
        string moveCounterBaseline = "Move Count: ";
        GameSave toSave;

        public Form1()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
        }

        private void Form1_OnLoad(object sender, EventArgs e)
        {
            Ellipse_radioButton.Checked = true;
            comboPieceNumber.Text = "3";
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            towerA.DrawTower(e.Graphics);
            towerB.DrawTower(e.Graphics);
            towerC.DrawTower(e.Graphics);
            if (shapeDrag != null)
                shapeDrag.Draw(e.Graphics);
        }

        private void Form1_OnMouseDown(object sender, MouseEventArgs e)
        {
            
            if ((shapeDrag = towerA.isInside(e)) != null) // check if in towerA
            {
                originalTower = WhichTower.first;
            }
            else if ((shapeDrag = towerB.isInside(e)) != null) // check if in towerB
            {
                originalTower = WhichTower.second;
            }
            else if ((shapeDrag = towerC.isInside(e)) != null) // check if in towerC
            {
                originalTower = WhichTower.third;
            }


            Mouse_Holding_Shape = shapeDrag != null; //if the shape isn't null then the mouse is holding a shape
        }

        private void Form1_OnMouseMove(object sender, MouseEventArgs e)
        {
            if (Mouse_Holding_Shape && shapeDrag != null)
            {
                shapeDrag.X = e.X;
                shapeDrag.Y = e.Y;
                Invalidate();
            }
        }

        private void Form1_OnMouseUp(object sender, MouseEventArgs e)
        {
            if (Mouse_Holding_Shape && shapeDrag != null)
            { 
                bool successfulMove = false;

                if (Math.Abs(e.X - towerA.TowerX) <= 30)
                {
                    successfulMove = towerA.TowerPush(shapeDrag);
                }
                else if (Math.Abs(e.X - towerB.TowerX) <= 30)
                {
                    successfulMove = towerB.TowerPush(shapeDrag);
                }
                else if (Math.Abs(e.X - towerC.TowerX) <= 30)
                {
                    successfulMove = towerC.TowerPush(shapeDrag);
                }
                
                if (successfulMove)
                {
                    ++moveCount;
                    lbl_MoveCounter.Text = moveCounterBaseline + moveCount;
                }
                else
                {
                    if (originalTower == WhichTower.first)
                        towerA.TowerPush(shapeDrag);
                    else if (originalTower == WhichTower.second)
                        towerB.TowerPush(shapeDrag);
                    else
                        towerC.TowerPush(shapeDrag);
                }

                Mouse_Holding_Shape = false;
                shapeDrag = null;
            }
            Invalidate();

            if (towerC.Count == Convert.ToInt32(comboPieceNumber.Text))
                EndGame();
        }

        private void EndGame()
        {
            string solvedIn = "Solved!! in " + moveCount + " Moves.\n";
            string thanks = "Thank You For Playing.\n";

            int optimal = (int)Math.Pow(2, towerC.Count) - 1;
            if (moveCount != optimal)
            {
                solvedIn += "Just so you know, you can solve it in " + optimal + " moves.\n";
            }

            DialogResult result;
            result = MessageBox.Show(thanks + solvedIn + "Go Again??\n", "Riddle Solved",
                                    MessageBoxButtons.YesNo, MessageBoxIcon.Information);

            if (result == DialogResult.Yes)
            {
                resetMovecount();
                ResetGame(WhichShape.Ellipse);
            }
            else
            {
                this.Close();
            }
        }

        private void comboPieceNumer_Changed(object sender, EventArgs e)
        {
            resetMovecount();
            towerA.Clear();
            towerB.Clear();
            towerC.Clear();

            if (Ellipse_radioButton.Checked)      ResetGame(WhichShape.Ellipse);

            else if (Hexagon_radioButton.Checked) ResetGame(WhichShape.Hexagon);

            else                                  ResetGame(WhichShape.Trapez);

            Invalidate();
        }

        private void ResetGame(WhichShape shape)
        {
            towerA.Clear();
            towerB.Clear();
            towerC.Clear();

            int amount = Convert.ToInt32(comboPieceNumber.Text);

            for (int i = amount - 1; i >= 0; --i)
            {
                switch (shape)
                {
                    case WhichShape.Ellipse: towerA.TowerPush(new Ellipse(0, 0, i * 4 + 10));
                        break;
                    case WhichShape.Hexagon: towerA.TowerPush(new Hexagon(0, 0, i * 4 + 10));
                        break;
                    case WhichShape.Trapez:  towerA.TowerPush(new Trapez(0, 0, i * 4 + 10));
                        break;
                }
            }
            Invalidate();
        }

        private void resetMovecount()
        {
            moveCount = 0;
            lbl_MoveCounter.Text = moveCounterBaseline + "0";
        }

        private void SelectedEllipse(object sender, EventArgs e)
        {
            towerA.ToEllipse();
            towerB.ToEllipse();
            towerC.ToEllipse();
            Invalidate();
        }

        private void SelectedHexagon(object sender, EventArgs e)
        {
            towerA.ToHexagon();
            towerB.ToHexagon();
            towerC.ToHexagon();
            Invalidate();
        }

        private void SelectedTrapez(object sender, EventArgs e)
        {
            towerA.ToTrapez();
            towerB.ToTrapez();
            towerC.ToTrapez();
            Invalidate();
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            toSave = new GameSave(towerA, towerB, towerC);

            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.InitialDirectory = Directory.GetCurrentDirectory();
            saveFileDialog1.Filter = "model files (*.mdl)|*.mdl|All files (*.*)|*.*";
            saveFileDialog1.FilterIndex = 1;
            saveFileDialog1.RestoreDirectory = true;
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                IFormatter formatter = new BinaryFormatter();
                using (Stream stream = new FileStream(saveFileDialog1.FileName, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    formatter.Serialize(stream, toSave);
                }
            }
        }

        private void btn_Load_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.InitialDirectory = Directory.GetCurrentDirectory();
            openFileDialog1.Filter = "model files (*.mdl)|*.mdl|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Stream stream = File.Open(openFileDialog1.FileName, FileMode.Open);
                var binaryFormatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                
                toSave = (GameSave)binaryFormatter.Deserialize(stream);

                towerA = toSave[0];
                towerB = toSave[1];
                towerC = toSave[2];
                Invalidate();
            }
        }
    }
}
