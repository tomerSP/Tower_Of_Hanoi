﻿using System.Drawing;

namespace Figures
{
    using System;
    using System.Collections.Generic;
    using System.Windows.Forms;

    [Serializable]
    public abstract class Shape
    {
        float x;
        float y;
        int pixel;
        
        protected Shape(float x_val, float y_val, int pixel_val)
        {
            x = x_val;
            y = y_val;
            pixel = pixel_val;
        }

        //Properties
        public float X { get => x; set => x = value; }
        public float Y { get => y; set => y = value; }
        public int Pixel { get => pixel; }
        public Brush Fill 
        {
            get
            {
                SolidBrush[] colorFill = { 
                    new SolidBrush(Color.Purple), new SolidBrush(Color.Blue), new SolidBrush(Color.Green),
                    new SolidBrush(Color.Yellow), new SolidBrush(Color.OrangeRed), new SolidBrush(Color.Red)
                };
                return colorFill[(pixel - 10) / 4];
            }
        }

        public abstract void MoveTo(int newX, int newY);

        public virtual void Draw(Graphics g) { }

        public abstract bool isInsideShape(int param_x, int param_y);
    }


    [Serializable]
    public class Ellipse : Shape
    {
        //Constructors
        public Ellipse(float x_val, float y_val, int pixel_val) : base(x_val, y_val, pixel_val) { }


        public override void Draw(Graphics g)
        {
            g.FillEllipse(Fill, X - 4.5f * Pixel, Y - Pixel, 9 * Pixel, 2 * Pixel);
            g.DrawEllipse(new Pen(Color.Black, 2), X - 4.5f * Pixel, Y - Pixel, 9 * Pixel, 2 * Pixel);
        }

        public override void MoveTo(int newX, int newY)
        {
            X = newX;
            Y = newY;
        }

        public override bool isInsideShape(int param_x, int param_y)
        {
            return Math.Abs(param_x - X) <= 4.5f * Pixel 
                && Math.Abs(param_y - Y) <= Pixel;
        }

        ~Ellipse() { }
    }

    [Serializable]
    public abstract class Polygon : Shape
    {
        PointF[] vertices;

        protected Polygon(float x_val, float y_val, int pixel_val)
                : base(x_val, y_val, pixel_val) { }

        public PointF[] Vertices
        {
            get { return vertices; }
            set { vertices = value; }
        }

        public PointF this[int index]
        {
            get { return vertices[index]; }
            set { vertices[index] = value; }
        }


        public override void Draw(Graphics g)
        {
            g.FillPolygon(Fill, Vertices);
            g.DrawPolygon(new Pen(Color.Black, 2), Vertices);
        }
    }

    [Serializable]
    public class Trapez : Polygon
    {
        public Trapez(float x_val, float y_val, int pixel_val) : base(x_val, y_val, pixel_val)
        {
            Vertices = new PointF[4];

            Vertices[0] = new PointF(X - 3.5f * Pixel, Y - 1.5f * Pixel); //top-left
            Vertices[1] = new PointF(X + 3.5f * Pixel, Y - 1.5f * Pixel); //top-right
            Vertices[2] = new PointF(X + 4.5f * Pixel, Y + 1.5f * Pixel); //bottom-right
            Vertices[3] = new PointF(X - 4.5f * Pixel, Y + 1.5f * Pixel); //bottom-left
        }

        public override void Draw(Graphics g)
        {
            base.Draw(g);
        }

        public override void MoveTo(int newX, int newY)
        {
            X = newX;
            Y = newY;
            Trapez moved = new Trapez(newX, newY, Pixel);
            this.Vertices = moved.Vertices;
        }

        public override bool isInsideShape(int param_x, int param_y)
        {
            return Math.Abs(param_x - X) <= 4.5f * Pixel
                && Math.Abs(param_y - Y) <= 1.5f * Pixel;
        }

        ~Trapez() { }
    }

    [Serializable]
    public class Hexagon : Polygon
    {
        public Hexagon(float x_val, float y_val, int pixel_val) : base(x_val, y_val, pixel_val)
        {
            Vertices = new PointF[6];

            Vertices[0] = new PointF(X - 2.5f * Pixel, Y - 1.5f * Pixel); //top-left
            Vertices[1] = new PointF(X + 2.5f * Pixel, Y - 1.5f * Pixel); //top-right
            Vertices[2] = new PointF(X + 4.5f * Pixel, Y); //right
            Vertices[3] = new PointF(X + 2.5f * Pixel, Y + 1.5f * Pixel); //bottom-right
            Vertices[4] = new PointF(X - 2.5f * Pixel, Y + 1.5f * Pixel); //bottom-left 
            Vertices[5] = new PointF(X - 4.5f * Pixel, Y); //left
        }

        public override void Draw(Graphics g)
        {
            base.Draw(g);
        }

        public override void MoveTo(int newX, int newY)
        {
            X = newX;
            Y = newY;
            Hexagon moved = new Hexagon(newX, newY, Pixel);
            this.Vertices = moved.Vertices;
        }

        public override bool isInsideShape(int param_x, int param_y)
        {
            return Math.Abs(param_x - X) <= 4 * Pixel
                && Math.Abs(param_y - Y) <= 1.5f * Pixel;
        }

        ~Hexagon() { }
    }

    [Serializable]
    public enum WhichTower { first, second, third }
    [Serializable]
    public enum WhichShape { Ellipse, Hexagon, Trapez }

    [Serializable]
    public class TowerOfHanoi : Stack<Shape>
    { 
        readonly int towerX, bottomTowerY = 350, topTowerY = 100;
        readonly int[] height = { 350, 300, 250, 200, 160, 130 };

        public TowerOfHanoi(WhichTower t)
        {
            towerX = 150 + ((int)t) * 300;
        }

        //Propeties
        public int TowerX => towerX;
        public int BottomTowerY => bottomTowerY;
        public int TopTowerY => topTowerY;


        //Methods
        public bool TowerPush(Shape input)
        {
            bool success = false;

            if (Count == 0 || input.Pixel < Peek().Pixel)
            {
                input.MoveTo(TowerX, height[this.Count]);
                Push(input);
                success = true;
            }

            return success;
        }

        public void DrawTower(Graphics g)
        {
            Shape[] arr = ToArray();

            for (int i = Count - 1; i >= 0; --i)
            {
                arr[i].Draw(g);
            }
            g.DrawLine(new Pen(Color.Black, 6), TowerX, BottomTowerY, TowerX, TopTowerY);
        }

        public Shape isInside(MouseEventArgs e)
        {
            if (this.Count > 0 && Peek().isInsideShape(e.X, e.Y))
            {
                return Pop();
            }

            return null;
        }

        public void ToEllipse()
        {
            Shape[] temp = ToArray();
            Array.Reverse(temp);

            Clear();
            foreach (Shape s in temp)
            {
                TowerPush(new Ellipse(s.X, s.Y, s.Pixel));
            }
        }

        public void ToHexagon()
        {
            Shape[] temp = ToArray();
            Array.Reverse(temp);

            Clear();
            foreach (Shape s in temp)
            {
                TowerPush(new Hexagon(s.X, s.Y, s.Pixel));
            }
        }

        public void ToTrapez()
        {
            Shape[] temp = ToArray();
            Array.Reverse(temp);

            Clear();
            foreach (Shape s in temp)
            {
                TowerPush(new Trapez(s.X, s.Y, s.Pixel));
            }
        }

        ~TowerOfHanoi() { Clear(); }
    }

    [Serializable]
    public class GameSave
    {
        readonly TowerOfHanoi[] allTowers = new TowerOfHanoi[3];

        public GameSave(TowerOfHanoi towerA, TowerOfHanoi towerB, TowerOfHanoi towerC)
        {
            allTowers[0] = towerA;
            allTowers[1] = towerB;
            allTowers[2] = towerC;
        }

        public TowerOfHanoi this[int index]
        {
            get 
            { 
                if (0 <= index && index <= 2) 
                    return allTowers[index];

                return null;
            }
        }

    }


}






